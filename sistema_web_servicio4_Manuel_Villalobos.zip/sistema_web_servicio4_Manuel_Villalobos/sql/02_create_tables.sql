USE work_order_system_db;

CREATE TABLE provision (
  id_provision INT NOT NULL,
  provision_name VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'VIGENTE',
  PRIMARY KEY (id_provision)
);

CREATE TABLE service (
  id_service INT NOT NULL,
  service_name VARCHAR(150) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'VIGENTE',
  PRIMARY KEY (id_service)
);

CREATE TABLE equipment (
  id_equipment INT NOT NULL,
  equipment_name VARCHAR(150) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'VIGENTE',
  PRIMARY KEY (id_equipment)
);

CREATE TABLE offer (
  id_offer INT NOT NULL AUTO_INCREMENT,
  offer_name VARCHAR(200) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'VIGENTE',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_offer)
);

CREATE TABLE service_provision (
  id_service INT NOT NULL,
  id_provision INT NOT NULL,
  PRIMARY KEY (id_service, id_provision)
);

CREATE TABLE equipment_provision (
  id_equipment INT NOT NULL,
  id_provision INT NOT NULL,
  PRIMARY KEY (id_equipment, id_provision)
);

CREATE TABLE offer_provision (
  id_offer INT NOT NULL,
  id_provision INT NOT NULL,
  PRIMARY KEY (id_offer, id_provision)
);

CREATE TABLE offer_service (
  id_offer INT NOT NULL,
  id_service INT NOT NULL,
  PRIMARY KEY (id_offer, id_service)
);

CREATE TABLE offer_equipment (
  id_offer INT NOT NULL,
  id_equipment INT NOT NULL,
  PRIMARY KEY (id_offer, id_equipment)
);
