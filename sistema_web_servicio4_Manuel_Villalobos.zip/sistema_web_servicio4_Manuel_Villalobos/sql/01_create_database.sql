DROP DATABASE IF EXISTS work_order_system_db;
CREATE DATABASE work_order_system_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE work_order_system_db;
