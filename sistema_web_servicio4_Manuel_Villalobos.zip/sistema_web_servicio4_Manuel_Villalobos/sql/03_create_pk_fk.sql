USE work_order_system_db;

ALTER TABLE service_provision
  ADD CONSTRAINT fk_service_provision_service
  FOREIGN KEY (id_service) REFERENCES service(id_service),
  ADD CONSTRAINT fk_service_provision_provision
  FOREIGN KEY (id_provision) REFERENCES provision(id_provision);

ALTER TABLE equipment_provision
  ADD CONSTRAINT fk_equipment_provision_equipment
  FOREIGN KEY (id_equipment) REFERENCES equipment(id_equipment),
  ADD CONSTRAINT fk_equipment_provision_provision
  FOREIGN KEY (id_provision) REFERENCES provision(id_provision);

ALTER TABLE offer_provision
  ADD CONSTRAINT fk_offer_provision_offer
  FOREIGN KEY (id_offer) REFERENCES offer(id_offer),
  ADD CONSTRAINT fk_offer_provision_provision
  FOREIGN KEY (id_provision) REFERENCES provision(id_provision);

ALTER TABLE offer_service
  ADD CONSTRAINT fk_offer_service_offer
  FOREIGN KEY (id_offer) REFERENCES offer(id_offer),
  ADD CONSTRAINT fk_offer_service_service
  FOREIGN KEY (id_service) REFERENCES service(id_service);

ALTER TABLE offer_equipment
  ADD CONSTRAINT fk_offer_equipment_offer
  FOREIGN KEY (id_offer) REFERENCES offer(id_offer),
  ADD CONSTRAINT fk_offer_equipment_equipment
  FOREIGN KEY (id_equipment) REFERENCES equipment(id_equipment);
