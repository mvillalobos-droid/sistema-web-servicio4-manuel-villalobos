USE work_order_system_db;

SELECT COUNT(*) AS total_prestaciones FROM provision;
SELECT COUNT(*) AS total_servicios FROM service;
SELECT COUNT(*) AS total_equipos FROM equipment;

SELECT s.id_service, s.service_name, p.id_provision, p.provision_name
FROM service s
JOIN service_provision sp ON s.id_service = sp.id_service
JOIN provision p ON sp.id_provision = p.id_provision
ORDER BY s.id_service;

SELECT e.id_equipment, e.equipment_name, p.id_provision, p.provision_name
FROM equipment e
JOIN equipment_provision ep ON e.id_equipment = ep.id_equipment
JOIN provision p ON ep.id_provision = p.id_provision
ORDER BY e.id_equipment;

SELECT o.id_offer, o.offer_name, o.status, o.created_at
FROM offer o
ORDER BY o.id_offer DESC;

SELECT o.id_offer, o.offer_name, p.provision_name
FROM offer o
JOIN offer_provision op ON o.id_offer = op.id_offer
JOIN provision p ON op.id_provision = p.id_provision
ORDER BY o.id_offer, p.id_provision;

SELECT o.id_offer, o.offer_name, s.service_name
FROM offer o
JOIN offer_service os ON o.id_offer = os.id_offer
JOIN service s ON os.id_service = s.id_service
ORDER BY o.id_offer, s.id_service;

SELECT o.id_offer, o.offer_name, e.equipment_name
FROM offer o
JOIN offer_equipment oe ON o.id_offer = oe.id_offer
JOIN equipment e ON oe.id_equipment = e.id_equipment
ORDER BY o.id_offer, e.id_equipment;
