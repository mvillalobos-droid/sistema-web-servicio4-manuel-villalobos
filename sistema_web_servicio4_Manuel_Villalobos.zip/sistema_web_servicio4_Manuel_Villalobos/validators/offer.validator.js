function toNumberList(list, fieldName) {
  if (!Array.isArray(list) || list.length === 0) {
    throw new Error(`El campo ${fieldName} es obligatorio y debe contener datos`);
  }

  const numberList = list.map((value) => Number(value));
  const hasInvalid = numberList.some((value) => !Number.isInteger(value) || value <= 0);

  if (hasInvalid) {
    throw new Error(`El campo ${fieldName} solo debe contener identificadores numéricos válidos`);
  }

  return [...new Set(numberList)];
}

function validateRequestData(data) {
  if (!data || typeof data !== 'object') {
    throw new Error('El request debe ser un objeto JSON válido');
  }

  if (!data.offerName || typeof data.offerName !== 'string' || data.offerName.trim() === '') {
    throw new Error('El campo offerName es obligatorio');
  }

  return {
    offerName: data.offerName.trim(),
    provisionList: toNumberList(data.provisionList, 'provisionList'),
    serviceList: toNumberList(data.serviceList, 'serviceList'),
    equipmentList: toNumberList(data.equipmentList, 'equipmentList')
  };
}

async function validateProvisionsExist(connection, provisionList) {
  const [rows] = await connection.query(
    'SELECT id_provision FROM provision WHERE id_provision IN (?) AND status = ?',
    [provisionList, 'VIGENTE']
  );

  const foundIds = rows.map((row) => row.id_provision);
  const missingIds = provisionList.filter((id) => !foundIds.includes(id));

  if (missingIds.length > 0) {
    throw new Error(`La prestación ${missingIds.join(', ')} no existe o no está vigente`);
  }
}

async function validateServicesExist(connection, serviceList) {
  const [rows] = await connection.query(
    'SELECT id_service FROM service WHERE id_service IN (?) AND status = ?',
    [serviceList, 'VIGENTE']
  );

  const foundIds = rows.map((row) => row.id_service);
  const missingIds = serviceList.filter((id) => !foundIds.includes(id));

  if (missingIds.length > 0) {
    throw new Error(`El servicio ${missingIds.join(', ')} no existe o no está vigente`);
  }
}

async function validateEquipmentExist(connection, equipmentList) {
  const [rows] = await connection.query(
    'SELECT id_equipment FROM equipment WHERE id_equipment IN (?) AND status = ?',
    [equipmentList, 'VIGENTE']
  );

  const foundIds = rows.map((row) => row.id_equipment);
  const missingIds = equipmentList.filter((id) => !foundIds.includes(id));

  if (missingIds.length > 0) {
    throw new Error(`El equipo ${missingIds.join(', ')} no existe o no está vigente`);
  }
}

async function validateServicesBelongToProvisions(connection, serviceList, provisionList) {
  const [rows] = await connection.query(
    `SELECT DISTINCT id_service
     FROM service_provision
     WHERE id_service IN (?)
       AND id_provision IN (?)`,
    [serviceList, provisionList]
  );

  const validServiceIds = rows.map((row) => row.id_service);
  const invalidServiceIds = serviceList.filter((id) => !validServiceIds.includes(id));

  if (invalidServiceIds.length > 0) {
    throw new Error(`El servicio ${invalidServiceIds.join(', ')} no pertenece a las prestaciones indicadas`);
  }
}

async function validateEquipmentBelongToProvisions(connection, equipmentList, provisionList) {
  const [rows] = await connection.query(
    `SELECT DISTINCT id_equipment
     FROM equipment_provision
     WHERE id_equipment IN (?)
       AND id_provision IN (?)`,
    [equipmentList, provisionList]
  );

  const validEquipmentIds = rows.map((row) => row.id_equipment);
  const invalidEquipmentIds = equipmentList.filter((id) => !validEquipmentIds.includes(id));

  if (invalidEquipmentIds.length > 0) {
    throw new Error(`El equipo ${invalidEquipmentIds.join(', ')} no pertenece a las prestaciones indicadas`);
  }
}

module.exports = {
  validateRequestData,
  validateProvisionsExist,
  validateServicesExist,
  validateEquipmentExist,
  validateServicesBelongToProvisions,
  validateEquipmentBelongToProvisions
};
