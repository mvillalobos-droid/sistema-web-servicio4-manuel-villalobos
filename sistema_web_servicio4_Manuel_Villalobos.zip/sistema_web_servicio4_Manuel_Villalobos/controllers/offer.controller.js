const offerService = require('../services/offer.service');

async function createOffer(req, res) {
  try {
    const offer = await offerService.createOffer(req.body);

    res.status(200).json({
      status: 'success',
      code: 200,
      message: 'Solicitud procesada correctamente',
      data: {
        idOffer: String(offer.idOffer),
        offerName: offer.offerName
      }
    });
  } catch (error) {
    res.status(404).json({
      status: 'error',
      code: 404,
      message: 'Recurso no encontrado',
      data: {
        observation: error.message
      }
    });
  }
}

module.exports = {
  createOffer
};
