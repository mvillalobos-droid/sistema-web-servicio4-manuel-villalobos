const pool = require('../db');
const offerValidator = require('../validators/offer.validator');

async function insertOffer(connection, offerName) {
  const [result] = await connection.query(
    'INSERT INTO offer (offer_name, status) VALUES (?, ?)',
    [offerName, 'VIGENTE']
  );

  return result.insertId;
}

async function insertOfferProvisions(connection, idOffer, provisionList) {
  const values = provisionList.map((idProvision) => [idOffer, idProvision]);
  await connection.query(
    'INSERT INTO offer_provision (id_offer, id_provision) VALUES ?',
    [values]
  );
}

async function insertOfferServices(connection, idOffer, serviceList) {
  const values = serviceList.map((idService) => [idOffer, idService]);
  await connection.query(
    'INSERT INTO offer_service (id_offer, id_service) VALUES ?',
    [values]
  );
}

async function insertOfferEquipment(connection, idOffer, equipmentList) {
  const values = equipmentList.map((idEquipment) => [idOffer, idEquipment]);
  await connection.query(
    'INSERT INTO offer_equipment (id_offer, id_equipment) VALUES ?',
    [values]
  );
}

async function createOffer(data) {
  const requestData = offerValidator.validateRequestData(data);
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    await offerValidator.validateProvisionsExist(connection, requestData.provisionList);
    await offerValidator.validateServicesExist(connection, requestData.serviceList);
    await offerValidator.validateEquipmentExist(connection, requestData.equipmentList);
    await offerValidator.validateServicesBelongToProvisions(
      connection,
      requestData.serviceList,
      requestData.provisionList
    );
    await offerValidator.validateEquipmentBelongToProvisions(
      connection,
      requestData.equipmentList,
      requestData.provisionList
    );

    const idOffer = await insertOffer(connection, requestData.offerName);
    await insertOfferProvisions(connection, idOffer, requestData.provisionList);
    await insertOfferServices(connection, idOffer, requestData.serviceList);
    await insertOfferEquipment(connection, idOffer, requestData.equipmentList);

    await connection.commit();

    return {
      idOffer,
      offerName: requestData.offerName
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = {
  createOffer
};
